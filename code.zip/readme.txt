group ID : 11
member's names: Hui Hon Man
email : hmhui@connect.ust.hk

Instructions:
1. Open the folder 'Game'
2. Open SpiderTale.exe
3. Press the tutorial to learn how to play
4. Press the Play to play
5. Play!
